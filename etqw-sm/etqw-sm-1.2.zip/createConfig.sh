#!/usr/bin/bash

echo "Creating config..."

cat <<EOF > /app/etqw_sm.json
{
    "uuid": "$UUID",
    "serversFolder": "$1"
}
EOF

echo "Finished creating config..."